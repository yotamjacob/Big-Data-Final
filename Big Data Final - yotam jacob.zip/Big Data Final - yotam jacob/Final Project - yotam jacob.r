library("data.table")
library("dplyr")
library("plyr")
library("proxy")
library("ggplot2")
library("datasets")
library("FactoMineR")
library("factoextra")

CreateData <- function(fileName){ #read and create data table
  mydata = fread(fileName)
  return(mydata)
}

CalcProximity <-function(mydata){ # First approach : wich indices has the highest proximity to NDVI?
  # Using proxy's similarity with the methods: cosine & correlation
  
  NDVI = mydata[["NDVI"]]
  
  proxy_summary_table<-data.frame("","","")
  names(proxy_summary_table)<-c('IndexName','Cosine','Correlation')
  proxy_summary_table = proxy_summary_table[-1,]
  
  for (i in 3:length(mydata)){
    y=as.vector(mydata[[i]])
    l <- list(NDVI, y)
    
    cosine=(simil(l, method="cosine")[1])
    correlation=(simil(l, method="correlation")[1])
    
    temp<-data.frame(colnames(mydata)[i],cosine,correlation)
    names(temp)<-c('IndexName','Cosine','Correlation')
    
    proxy_summary_table <- rbind(proxy_summary_table, temp)
  }
  return(proxy_summary_table)
}

visualize <-function(method,proxy_summary_table){  #Find and show the top 5 by selected method's proximity:
  
  top5 = proxy_summary_table %>% top_n(5,proxy_summary_table[[method]])
  keeps <- c('IndexName',method)
  filtered = top5[keeps]
  sorted <- filtered[order(-filtered[[method]]),] 
  
  print(paste0("Top 5 indices by ",method,":"))
  print(sorted)
  
  df = data.frame(sorted)
  #plot it
  bars = ggplot(df, aes(IndexName, sorted[[method]])) +
    geom_linerange(
      aes(x = IndexName, ymin = 0.86, ymax = sorted[[method]]), 
      color = "lightgray", size = 1
    )+
    geom_point(aes(color = IndexName), size = 4)+
    ggpubr::color_palette("jco") + 
    geom_text(aes(label=sorted[[method]]),hjust=0.5, vjust=-1)+
    theme(axis.title.x=element_blank(),axis.title.y=element_blank(),plot.title = element_text(hjust = 0.5)) + ggtitle(method)
  
  plot(bars)
  return(sorted)
}

CalcRSQ <-function(mydata){ # Second approach : calulate R^2 values between NDVI and all indices and choose the top 5

  NDVI = mydata[["NDVI"]]
  
  Rsquared_summary_table<-data.frame("","")
  names(Rsquared_summary_table)<-c('IndexName','Rsquared_Value')
  Rsquared_summary_table = Rsquared_summary_table[-1,]
  
  for (i in 3:length(mydata)){
    y=as.vector(mydata[[i]])
    
    rsq <- function(x, y) summary(lm(y~x))$r.squared
    rsq_value = rsq(NDVI, y)
    
    temp<-data.frame(colnames(mydata)[i],rsq_value)
    names(temp)<-c('IndexName','Rsquared_Value')
    
    Rsquared_summary_table <- rbind(Rsquared_summary_table, temp)
  }
  return(Rsquared_summary_table)
}

behavior <-function(highestCos,highestCorr,highestRSQ,mydata){ # Third Approach: take the best 3 indices and measure behavior by comparing Spectrums
  cos_index = (paste0(factor(highestCos[1,1]),max.levels = 0))
  corr_index = (paste0(factor(highestCorr[1,1]),max.levels = 0))
  rsq_index = (paste0(factor(highestRSQ[1,1]),max.levels = 0))
  #Extract indices names
  cos_index = substr(cos_index,1,nchar(cos_index)-1)
  corr_index = substr(corr_index,1,nchar(corr_index)-1)
  rsq_index = substr(rsq_index,1,nchar(rsq_index)-1)
  
  cos = mydata[[cos_index]]
  corr = mydata[[corr_index]]
  rsq = mydata[[rsq_index]]
  
  ndvi = mydata[["NDVI"]]
  #cluster and count the clusters nodes
  clusterCounts1 = clustering(ndvi,cos,cos_index)
  clusterCounts2 = clustering(ndvi,corr,corr_index)
  clusterCounts3 = clustering(ndvi,rsq,rsq_index)
  counts_summary = cbind(clusterCounts1,clusterCounts2,clusterCounts3)
  names(counts_summary) = c("clusters",cos_index,"clusters",corr_index,"clusters",rsq_index)
  print(counts_summary)
}

clustering <- function(ndvi,indexData,indexName){ #create clusters on selected index and plot it

  output = data.frame(cbind(indexData,ndvi))
  names(output) <- c(indexName,"NDVI")
  
  # Cluster
  d <- dist(scale(output), method="euclidean", diag=TRUE, upper=TRUE)
  hls <- hclust(d, method="complete")
  
  # Create groups
  cluster <- cutree(hls, 5)
  
  # Create scatter plot
  ggData <- cbind(output, cluster)
  ggData$cluster <- as.factor(ggData$cluster)
  mydf = data.frame(ggData)
  
  clusters = ggplot(ggData, aes(x=output[[indexName]], y=output$NDVI, color=cluster)) + geom_point(size=2) +
    theme(axis.title.x=element_blank(),axis.title.y=element_blank(),plot.title = element_text(hjust = 0.5)) + 
    ggtitle(indexName)
  plot(clusters)
  count = count(mydf, "cluster")
  return(count)
}

#______Main_____#:
fileName = "Data_JUL_18.csv"
mydata = CreateData(fileName)
proxy_table=CalcProximity(mydata)

method = "Cosine"
highestCos=visualize(method,proxy_table)

method = "Correlation"
highestCorr=visualize(method,proxy_table)

rsq_table=CalcRSQ(mydata)
method = "Rsquared_Value"
highestRSQ=visualize(method,rsq_table)

behavior(highestCos[1:1,1:2],highestCorr[1:1,1:2],highestRSQ[1:1,1:2],mydata)
